import { Button as AntButton, Card } from "antd";
import { Button } from "../ui/button";
import StopList from "./StopList";

export default function StopListPanel() {

  return (
    <div className="space-y-4">

      <Card>
        <div className="flex justify-between text-sm">
          <span className="font-semibold">ABC23</span>

          <AntButton color="cyan" variant="solid">
            Save
          </AntButton>

          <AntButton color="green" variant="solid">
            Upload
          </AntButton>
        </div>

        <div className="flex justify-between text-sm mt-3">
          <Button className="bg-red-600 text-white px-4">
            Back
          </Button>
          <Button className="bg-cyan-600 text-white px-4">
            Create Journey
          </Button>
          <Button className="bg-green-700 text-white px-4">
            Update
          </Button>
        </div>

      </Card>


      {/* Stop Cards */}

      <StopList />
      {/* <div className="space-y-3 mt-3">

        <Badge.Ribbon text="1">
          <StopCard
            route="TEST"
            type="PICKING"
            stops={0}
            passengers={0}
          />
        </Badge.Ribbon>

        <Badge.Ribbon text="2">
          <StopCard
            route="TRIAL ROUTE"
            type="PICKING"
            stops={5}
            passengers={0}
          />
        </Badge.Ribbon>

      </div> */}

    </div>
  )
}