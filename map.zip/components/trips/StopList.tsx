"use client"

import {
    DndContext,
    closestCenter,
} from "@dnd-kit/core"

import { restrictToVerticalAxis } from "@dnd-kit/modifiers"
import {
    SortableContext,
    arrayMove,
    verticalListSortingStrategy,
} from "@dnd-kit/sortable"

import { useState } from "react"
import SortableItem from "./SortableItem"

const initialData = [
    { id: "1", route: "TEST", type: "PICKING", stops: 0, passengers: 0 },
    { id: "2", route: "TRIAL ROUTE", type: "PICKING", stops: 5, passengers: 0 },
]

export default function StopList() {
    const [items, setItems] = useState(initialData)

    const handleDragEnd = (event: any) => {
        const { active, over } = event

        if (!over || active.id === over.id) return

        const oldIndex = items.findIndex(i => i.id === active.id)
        const newIndex = items.findIndex(i => i.id === over.id)

        setItems(arrayMove(items, oldIndex, newIndex))
    }

    return (
        <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}
            modifiers={[restrictToVerticalAxis]} >
            <SortableContext items={items} strategy={verticalListSortingStrategy}>
                <div className="space-y-3 mt-3">
                    {items.map((stop, index) => (
                        <SortableItem key={stop.id} id={stop.id} stop={stop} index={index} />
                    ))}
                </div>
            </SortableContext>
        </DndContext>
    )
}