import { useTripStore } from "@/store/trip-store"

export function StopCard({ route, type, stops, passengers }: TripCardProps) {

    const { showMapOrStopForm, toggleShowMapOrStopForm, setShowMapOrStopForm } = useTripStore()


    return (
        <div className="border rounded-lg p-3 shadow-sm">

            {/* <div className="flex justify-between"> */}
            <div className="font-medium">Near Diamong Point</div>
            <div>Passenger: 2</div>
            {/* </div> */}

            <div className="flex justify-end text-sm gap-3">
                <button className="mt-3 border rounded px-5 py-1 text-sm bg-red-500 text-white hover:bg-red-700 cursor-pointer">
                    Delete
                </button>
                <button className="mt-3 border rounded px-5 py-1 text-sm bg-red-500 text-white hover:bg-red-700 cursor-pointer"
                    onClick={() => {
                        showMapOrStopForm && setShowMapOrStopForm(false)
                    }}
                >
                    Edit
                </button>
            </div>

        </div>
    )
}

type TripCardProps = {
    route: string
    type: string
    stops: number
    passengers: number
}