import { Button as AntBtn, Checkbox, Drawer, DrawerProps, Flex, GetProp, Radio } from "antd";
import { CheckboxGroupProps } from "antd/es/checkbox";
import { useState } from "react";
import { Button } from "../ui/button";
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel, FieldTitle } from "../ui/field";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

type StopFormProps = {
    setShowMap: (value: boolean) => void
}

export default function StopForm({ setShowMap }: StopFormProps) {

    const options: string[] = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
    ];
    const format = 'HH:mm';

    const [tripType, setTripType] = useState<string>("PICKING");
    const [tripEnable, setTripEnable] = useState<boolean>(true);
    const [drawerOpen, setDrawerOpen] = useState<boolean>(false);

    const onChange: GetProp<typeof Checkbox.Group, 'onChange'> = (checkedValues) => {
        console.log('checked = ', checkedValues);
    };

    const types: CheckboxGroupProps<string>['options'] = [
        { label: 'PICKING', value: 'PICKING' },
        { label: 'DROPPING', value: 'DROPPING' },
    ];
    const states: CheckboxGroupProps<boolean>['options'] = [
        { label: 'ENABLE', value: true },
        { label: 'DISABLE', value: false },
    ];

    const stylesFn: DrawerProps['styles'] = (info) => {
        if (info.props.footer) {
            return {
                header: {
                    padding: 16,
                },
                body: {
                    padding: 16,
                },
                footer: {
                    padding: '10px 10px',
                    backgroundColor: '#fafafa',
                },
            } satisfies DrawerProps['styles'];
        }
        return {};
    };

    const footer: React.ReactNode = (
        <Flex gap="medium" justify="center">
            <AntBtn
                type="primary"
                styles={{ root: { backgroundColor: '#171717' } }}
                onClick={() => setDrawerOpen(true)}
                size="large"
            >
                Submit
            </AntBtn>
        </Flex>
    );

    const sharedProps: DrawerProps = {
        size: 425,
    };

    return (
        <div className="w-full">

            <h2 className="text-xl font-semibold text-center text-gray-600 mb-6 w-full">
                Edit Stop
            </h2>

            <div className="grid grid-cols-[180px_1fr] gap-y-4 gap-x-4 items-center ">

                <span className="text-[15px] text-end">Stop Id:</span>
                <Input
                    disabled
                    placeholder="stop id"
                    className="border p-1.5 rounded w-full"
                />

                <span className="text-[15px] text-end">Stop Name:</span>
                <Input
                    placeholder="stop name"
                    className="border p-1.5 rounded w-full"
                />

                <span className="text-[15px] text-end">Stop Latitude:</span>
                <Input
                    type="number"
                    placeholder="latitude"
                    className="border p-1.5 rounded w-full"
                />

                <span className="text-[15px] text-end">Stop Longitude:</span>
                <Input
                    type="number"
                    placeholder="longitude"
                    className="border p-1.5 rounded w-full"
                />

                <span className="text-[15px] text-end">Stop Type:</span>
                <FieldGroup className="w-full">
                    <Field orientation="horizontal">

                        <Select defaultValue="point">
                            <SelectTrigger className="w-[50%]">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent
                                position={false ? "item-aligned" : "popper"}
                            >
                                <SelectGroup>
                                    <SelectItem value="bus">Bus Stop</SelectItem>
                                    <SelectItem value="point">Drop / Picking Point</SelectItem>
                                    <SelectItem value="institute">Institute</SelectItem>
                                </SelectGroup>
                            </SelectContent>
                        </Select>
                    </Field>
                </FieldGroup>

                <span className="text-[15px] text-end">Stop State:</span>
                <Radio.Group
                    options={states}
                    value={tripEnable}
                    optionType="button"
                    buttonStyle="solid"
                    onChange={e => setTripEnable(e.target.value)}
                />


                <Drawer
                    {...sharedProps}
                    footer={footer}
                    title="Select Students"
                    styles={stylesFn}
                    mask={{ enabled: true, blur: true }}
                    open={drawerOpen}
                    onClose={() => setDrawerOpen(false)}
                    destroyOnHidden={false}
                >
                    <div className="w-full">
                        <FieldGroup className="max-w-sm gap-3">
                            <FieldLabel>
                                <Field orientation="horizontal">
                                    <Checkbox id="toggle-checkbox-1" name="toggle-checkbox-1" />
                                    <FieldContent>
                                        <FieldTitle>Student 1</FieldTitle>
                                        <FieldDescription>
                                            XII - ABC123
                                        </FieldDescription>
                                    </FieldContent>
                                </Field>
                            </FieldLabel>
                            <FieldLabel>
                                <Field orientation="horizontal">
                                    <Checkbox id="toggle-checkbox-2" name="toggle-checkbox-2" />
                                    <FieldContent>
                                        <FieldTitle>Student 2</FieldTitle>
                                        <FieldDescription>
                                            XII - ABC123
                                        </FieldDescription>
                                    </FieldContent>
                                </Field>
                            </FieldLabel>
                            <FieldLabel >
                                <Field orientation="horizontal" className="w-full">
                                    <Checkbox id="toggle-checkbox-3" name="toggle-checkbox-3" />
                                    <FieldContent>
                                        <FieldTitle>Student 3</FieldTitle>
                                        <FieldDescription>
                                            XII - ABC123
                                        </FieldDescription>
                                    </FieldContent>
                                </Field>
                            </FieldLabel>
                        </FieldGroup>
                    </div>
                </Drawer>

            </div>

            <div className="flex justify-center mt-5 gap-5">
                <Button className="bg-green-700 text-white px-4 py-2 rounded" onClick={() => setShowMap(true)}>
                    Update
                </Button>

                <Button className="bg-red-600 text-white px-4 py-2 rounded" onClick={() => setShowMap(true)}>
                    Close
                </Button>
            </div>

        </div >
    )
}