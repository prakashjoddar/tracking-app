export class RouteManager {

    private map: google.maps.Map
    private polyline: google.maps.Polyline | null = null

    constructor(map: google.maps.Map) {
        this.map = map
    }

    drawEncodedRoute(encoded: string) {
        const path = google.maps.geometry.encoding.decodePath(encoded)

        new google.maps.Marker({
            position: path[0],
            map: this.map
        })

        console.log(google.maps.geometry)
        console.log("Decoded path:", path)
        console.log("Length:", path.length)

        if (!this.polyline) {
            this.polyline = new google.maps.Polyline({
                strokeColor: "#2563eb",
                strokeWeight: 4,
                map: this.map
            })
        }

        this.polyline.setPath(path)

        // fit bounds
        const bounds = new google.maps.LatLngBounds()
        path.forEach(p => bounds.extend(p))
        this.map.fitBounds(bounds)
    }

}