"use client"

import { GoogleMapView } from "@/components/map/GoogleMapView";
import StopForm from "@/components/trips/StopForm";
import StopListPanel from "@/components/trips/StopListPanel";
import { useTripStore } from "@/store/trip-store";

export default function StopsPage() {

    const { showMapOrStopForm, toggleShowMapOrStopForm, setShowMapOrStopForm } = useTripStore()

    return (
        <div className="flex h-full w-full">

            {/* LEFT PANEL */}
            {/* <div className={showMap ? "w-[400px] border-r p-4" : "w-full p-4"}>
               
            </div> */}
            <div className="w-[420px] border-r p-4 overflow-y-auto">
                <StopListPanel />
            </div>

            {/* RIGHT PANEL */}
            {showMapOrStopForm ? (
                <div className="flex-1">
                    <GoogleMapView />
                </div>
            ) : <div className="flex-1 p-6">
                <StopForm setShowMap={setShowMapOrStopForm} />
            </div>}

        </div>
    )
}