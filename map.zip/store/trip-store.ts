import { create } from "zustand";

type State = {
  showMapOrStopForm: boolean;

  setShowMapOrStopForm: (val: boolean) => void;
  toggleShowMapOrStopForm: () => void;
};

export const useTripStore = create<State>((set) => ({
  showMapOrStopForm: false,

  setShowMapOrStopForm: (p) => set({ showMapOrStopForm: p }),
  toggleShowMapOrStopForm: () =>
    set((s) => ({ showMapOrStopForm: !s.showMapOrStopForm })),
}));
